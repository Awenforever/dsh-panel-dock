export const DEFAULT_WIDTH = 320
export const MIN_WIDTH = 200
export const MAX_WIDTH = 720
export const STORE_KEY = 'dsh.panel-dock.v1'
export const SPLITTER_WIDTH = 5
export const MIN_CONVERSATION = 420

export function clampWidth(width) {
  const value = Number(width)
  if (!Number.isFinite(value)) return DEFAULT_WIDTH
  return Math.round(Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, value)))
}

export function heightStyle(height) {
  if (height === 'fill') return { flex: '1 1 0' }
  if (height === 'auto') return { flex: '0 0 auto' }
  const px = Number(height)
  if (!Number.isFinite(px) || px <= 0) return { flex: '1 1 0' }
  return { flex: '0 0 ' + Math.round(px) + 'px' }
}

export function normalizePanels(panels) {
  const list = Array.isArray(panels) ? panels.slice() : []
  return list.sort((a, b) => {
    const ao = Number.isFinite(a.order) ? a.order : 100
    const bo = Number.isFinite(b.order) ? b.order : 100
    if (ao !== bo) return ao - bo
    return String(a.id).localeCompare(String(b.id))
  })
}

export function defaultLayout() {
  return { width: DEFAULT_WIDTH, collapsed: {}, sides: {}, open: false }
}

export function parseLayout(raw) {
  if (typeof raw !== 'string' || raw === '') return defaultLayout()
  let parsed = null
  try { parsed = JSON.parse(raw) } catch { return defaultLayout() }
  if (!parsed || typeof parsed !== 'object') return defaultLayout()
  const collapsed = {}
  if (parsed.collapsed && typeof parsed.collapsed === 'object') {
    for (const key of Object.keys(parsed.collapsed)) collapsed[key] = parsed.collapsed[key] === true
  }
  const sides = {}
  if (parsed.sides && typeof parsed.sides === 'object') {
    for (const key of Object.keys(parsed.sides)) {
      const value = parsed.sides[key]
      if (value === 'left' || value === 'right') sides[key] = value
    }
  }
  return { width: clampWidth(parsed.width), collapsed, sides, open: parsed.open === true }
}

export function serializeLayout(layout) {
  return JSON.stringify({
    width: clampWidth(layout && layout.width),
    collapsed: Object.assign({}, (layout && layout.collapsed) || {}),
    sides: Object.assign({}, (layout && layout.sides) || {}),
    open: Boolean(layout && layout.open),
  })
}

export function isCollapsed(layout, id) {
  return Boolean(layout && layout.collapsed && layout.collapsed[id] === true)
}

export function cloneLayout(layout) {
  return {
    width: clampWidth(layout && layout.width),
    collapsed: Object.assign({}, (layout && layout.collapsed) || {}),
    sides: Object.assign({}, (layout && layout.sides) || {}),
    open: Boolean(layout && layout.open),
  }
}

export function toggleCollapsed(layout, id) {
  const next = cloneLayout(layout)
  next.collapsed[id] = next.collapsed[id] !== true
  return next
}

export function visiblePanels(panels, layout) {
  return normalizePanels(panels).filter((panel) => panel && typeof panel.id === 'string')
}

// The strip may not squeeze the conversation below MIN_CONVERSATION. The stored
// width is the user preference; the effective width is what the frame can afford.
export function effectiveStripWidth(stageWidth, preferred, splitter = SPLITTER_WIDTH) {
  const stage = Number(stageWidth)
  if (!Number.isFinite(stage) || stage <= 0) return clampWidth(preferred)
  const affordable = Math.floor(stage - MIN_CONVERSATION - splitter)
  const capped = Math.min(clampWidth(preferred), affordable)
  return Math.max(MIN_WIDTH, capped)
}

// Where a panel currently lives. The panel definition supplies the default; the
// layout remembers the user choice made through the panel own toggle button.
export function effectiveSide(layout, id, fallback = 'right') {
  const stored = layout && layout.sides ? layout.sides[id] : undefined
  if (stored === 'left' || stored === 'right') return stored
  return fallback === 'left' ? 'left' : 'right'
}

export function withSide(layout, id, side) {
  const next = cloneLayout(layout)
  if (side === 'left' || side === 'right') next.sides[id] = side
  else delete next.sides[id]
  return next
}

export function otherSide(side) {
  return side === 'left' ? 'right' : 'left'
}
